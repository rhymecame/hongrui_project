import React from 'react';


export default class HRQualification extends React.Component {
    render(){
        return (
            <div>
                    <h2>专业承包资质：</h2>
                    <p/>
                    建筑装饰装修工程设计与施工一体化壹级

地基与基础工程壹级

消防设施工程壹级

建筑幕墙工程设计与施工壹级

钢结构工程壹级

化工石油设备管道安装工程贰级

建筑智能化工程设计与施工贰级

管道工程贰级

桥梁工程贰级

隧道工程贰级

环保工程贰级

炉窖工程贰级
            </div>
        );
    }
}