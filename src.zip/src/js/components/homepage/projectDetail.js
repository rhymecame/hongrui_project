


export const projectDetail = 
    [
        {

        },
        //第0个留空，从1开始
        {
            id: 1,
            projectName: '工程1',
            imgSrc: './src/images/villa.jpeg',
            projectDesc: '这是工程1的简介',
        },
        {
            id: 2,
            projectName: '工程2',
            imgSrc: './src/images/the_beau.jpeg',
            projectDesc: '这是工程2的简介',
        },
        {
            id: 3,
            projectName: '工程3',
            imgSrc: './src/images/the_play.jpeg',
            projectDesc: '这是工程3的简介',
        },
        {
            id: 4,
            projectName: '工程4',
            imgSrc: './src/images/infra.jpeg',
            projectDesc: '这是工程4的简介',
        },
    ];
